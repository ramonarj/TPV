#include "RenderComponent.h"

RenderComponent::RenderComponent() {
	// TODO Auto-generated constructor stub

}

RenderComponent::~RenderComponent() {
	// TODO Auto-generated destructor stub
}

