#include "PhysicsComponent.h"

PhysicsComponent::PhysicsComponent() {
	// TODO Auto-generated constructor stub

}

PhysicsComponent::~PhysicsComponent() {
	// TODO Auto-generated destructor stub
}

