This is the basic ping-pong using the component design pattern like ver_4, but the GameManager is also define using components.
