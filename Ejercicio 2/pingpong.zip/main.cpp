#include <math.h>
#include "ExampleGame.h"

using namespace std;

int main(int ac, char** av) {
	ExampleGame g;
	g.start();
	return 0;
}
